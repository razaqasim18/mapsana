// $(document).ready(function () {

// 	$('.input_otp').on('input', function () {
// 		var $this = $(this);
// 		if ($this.val().length >= 1) {
// 			$this.next('.input_otp').focus();
// 		}
// 		else {
// 			$this.prev('.input_otp').focus();
// 		}
// 	}

// });
